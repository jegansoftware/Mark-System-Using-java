package Array_one;
import java.util.*;
public class Class1 {
private	int[] a;
private int n;
private int Sum=0;

// array declaration
	public Class1()
	{
		String[] sub1;
		int i;
				
		sub1=new String[6];
		sub1[0]="Tamil  Mark      :";
		sub1[1]="English Mark     :";
		sub1[2]="Mathematics Mark :";
		sub1[3]="Science  Mark    :";
		sub1[4]="Social  Mark     :";
		sub1[5]="Enter ";
	
		a=new int[5];	
		for(i=0;i<5;i++)
		{
			System.out.printf("\n%s %s\n",sub1[5],sub1[i]);
			
			Scanner in=new Scanner(System.in);
			a[i]=in.nextInt();
			in=null;
		}
	}

//------------------------------------------------------------------------------------
	// find min
	public void min_max()
	{
		int i;
		int min=a[0];
		for(i=0;i<5;i++)
		{
			if(a[0]>a[i])
			{
				min=a[i];
			}
		}
		System.out.printf("\nMINIMUM :  %d", min);
	}
	
//---------------------------------------------------------------------------------------------
	//display the mark
	public void display()
	{
		int i;
		int pass=0;
		int fail=0;
		String status="";
		String[] sub;
		sub= new String[6];
		sub[0]="1)Tamil        ";
		sub[1]="2)English      ";
		sub[2]="3)Mathematics  ";
		sub[3]="4)Science      ";
		sub[4]="5)Social       ";
		for(i=0;i<5;i++)
		{
			if(a[i]>=35)
			{
				status="Pass";
				pass++;
			}
			else
			{
				status="Fail";
				fail=1;
			}
			
			if(a[i]>100)
			{
				a[i]=100;
			}
			
			System.out.printf("\n  %s  :   %3d      %s",sub[i],a[i],status);
		}
			    
		    
		if(pass==5)
		{
			System.out.printf("\n   You have gotten through the exam");
		}
		else
		{ 
			System.out.printf("\n   You have failed the exam");
		}

		
		
		
		
	}
//-------------------------------------------------------------------------------------------------
	//sum the total values
	public void sum()
	{
		int i;
		
		for(i=0;i<5;i++)
		{
			Sum=Sum+a[i];
		}
		
		System.out.printf("Total Mark : %d",Sum);
	}
//-----------------------------------------------------------------------------------------------------------	
	
	
	
	
	
	
	
	
	
	
	
//---------------------------------------------------------------------------------------------------------	
	//find max
			
		public void max_min()
		{
			int i;
			int max=a[0];
			for(i=0;i<5;i++)
			{
			if(a[0]<a[i])
			{
				max=a[i];
			}
			}
			System.out.printf("\nMAXIMUM :  %d", max);
			a=null;
		}
		
//-----------------------------------------------------------------------------------------------------------------		

}
