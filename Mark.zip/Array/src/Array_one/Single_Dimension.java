package Array_one;
import java.util.*;
public class Single_Dimension {

	public static void main(String[] args) {
		int n;
		Class1 arr=new Class1();
		//arr.min_max();
		
		Scanner ne=new Scanner(System.in);
		System.out.printf("\n1) MINIMUM MARK");
		
		System.out.printf("\n2) MAXIMUM MARK");
		
		System.out.printf("\n3) DISPLAY MARK\n");
		
		System.out.printf("\nChoose your option :\n");
		n=ne.nextInt();
		
		switch(n)
		{
		case 1:
		{
			arr.min_max();
			arr=null;
			System.out.printf("\n\nMinimum Value Has been Displayed");
			break;
		}
		case 2:
		{
			arr.max_min();
			arr=null;
			System.out.printf("\n\nMaximum Value Has been Displayed");
			break;
		}
		case 3:
		{
			arr.display();
			arr=null;
			System.out.printf("\n\nYour mark has been Dispalyed");
			System.out.printf("\n\nMake sure your marks,if you find any correction.Please Feel free make a call at +91 9003824096");
			break;
		}
		
		case 4:
		{
			arr.sum();
			arr=null;
			
			System.out.printf("\n\nTotal Mark has been displayed");
			break;
		}
			
		}
		
		
		
		
	}

}
